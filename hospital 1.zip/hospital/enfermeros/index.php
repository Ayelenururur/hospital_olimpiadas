<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/home.css">
    <!-- https://icons.getbootstrap.com/ -->
  </head>
<body>

<div class="container mt-3">
  <div class="row justify-content-md-center">
    <div class="col-md-12">
        <a href="./"><i class="bi bi-house"></i></a>
        <hr class="mb-3">
    </div>


    <div class="col-md-4 mb-3">
      <h3 class="text-center">Datos </h3>
      <form method="POST" action="alta.php" enctype="multipart/form-data">
        <input type="text" name="metodo" value="1" hidden>
      <div class="mb-3">
          <label class="form-label"> Apellido</label>
          <input type="text" class="form-control" name="namefull" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Nombre </label>
          <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Fecha de Nacimiento </label>
          <input type="number" name="fecha_nac" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">dni </label>
          <input type="number" name="dni" class="form-control" required>
        </div>

        <div class="mb-3">
        <label for="Sexo">Sexo </label>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="sexo" value="M" checked>
            <label class="form-check-label" for="sexoM">
              Masculino
            </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="sexo" value="F">
          <label class="form-check-label" for="sexoF">
            Fememino
          </label>
        </div>
        </div>
        

        <div class="d-grid gap-2 col-12 mx-auto">
          <button type="submit" class="btn  btn btn-primary mt-3 mb-2">
            Registrar nuevo 
            <i class="bi bi-arrow-right-circle"></i>
          </button>
        </div>
        
      </form>
    </div>


    
    <?php
    include('conexion.php');
    $sql  = ("SELECT * FROM pacientes ORDER BY id_paciente");
    $query = pg_query($sql);
    $total = pg_num_rows($query);

    ?>
    <div class="col-md-8">
    <h3 class="text-center">Lista de  <?php echo '(' . $total . ')'; ?></h3>
      <div class="row">
        <div class="col-md-12 p-2">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th scope="col">Apellido</th>
                  <th scope="col">Nombre</th>
                  <th scope="col">DNI </th>
                  <th scope="col">Fecha_Nacimiento</th>
                  <th scope="col">Sexo</th>
                </tr>
              </thead>
              <tbody>
              <?php
              while ($dataAlumno = pg_fetch_array($query)) { ?>
                <tr>
                  <td><?php echo $dataAlumno['namefull']; ?></td>
                  <td><?php echo $dataAlumno['apellido']; ?></td>
                  <td><?php echo $dataAlumno['nombre']; ?></td>
                  <td><?php echo $dataAlumno['fecha_nac']; ?></td>

                  <td><?php echo $dataAlumno['dni']; ?></td>
                  <td><?php echo $dataAlumno['sexo']==='M' ?  'Masculino' : 'Femenino' ?></td>
                  <td>
                  <a href="detalles.php?id=<?php echo $dataAlumno['id']; ?>" class="btn btn-warning mb-2"   title="Ver datos del alumno <?php echo $dataAlumno['namefull']; ?>">
                  <i class="bi bi-tv"></i> Ver</a>
                    <a href="formEditar.php?id=<?php echo $dataAlumno['id']; ?>" class="btn btn-info mb-2"   title="Actualizar datos del alumno <?php echo $dataAlumno['namefull']; ?>">
                    <i class="bi bi-arrow-clockwise"></i> Actualizar</a>
                    <a href="action.php?id=<?php echo $dataAlumno['id']; ?>&metodo=3&namePhoto=<?php echo $dataAlumno['foto']; ?>" class="btn btn-danger mb-2" title="Borrar el alumno <?php echo $dataAlumno['namefull']; ?>">
                    <i class="bi bi-trash"></i> Borrar</a>
                  </td>
                </tr>
              <?php } ?>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php
  include('mensajes.php'); 
?>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script>
$(function(){
  $('.toast').toast('show');
});
</script>

</body>
</html>
<style>
    body{
    background-color: #f9f9f9 !important;
  }
  .container{
    background-color: #fff;
    border-radius: 10px !important;
  }
  h1{
    font-weight: 800;
    color: blueviolet;
  }
  p{
    font-size: 35px;
    font-weight: 800;
    color: orange;
  }
  p span{
    color: crimson;
  }
  label{
    color: #333 !important;
    font-weight: 500;
  }
  .bi-trash:hover{
    color: #333 !important;
  }
  .bi-arrow-clockwise:hover{
    color: green;
    font-weight: bold;
  }
  a{
    text-decoration: none;
  }
  .bi-arrow-left-circle{
    color: #666;
  }
  .bi-arrow-left-circle:hover{
    color: green;
  }
  .fotoPerfil{
    margin: 0 auto;
    max-width: 250px;
}
.titleAlumno{
    color: orange;
    font-weight: 800;
}
.logo{
  max-width: 50px;
}
.msjexito{
  color: green;
}
</style>