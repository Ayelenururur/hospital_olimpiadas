<?php
require("conexion.php");

$dni = $_POST["dni"];
$apellido = $_POST["apellido"];
$nombre = $_POST["nombre"];
$sexo = $_POST["sexo"];
$fecha_nac = $_POST["fecha_nac"];
$query=("INSERT INTO pacientes ( dni, apellido, nombre, sexo, fecha_nac   ) VALUES (  '$dni', '$apellido', '$nombre', '$sexo', '$fecha_nac' );");
$consulta=pg_query($conexion,$query);

pg_close();

echo 'se rañado un producto nuevo';         

?>
