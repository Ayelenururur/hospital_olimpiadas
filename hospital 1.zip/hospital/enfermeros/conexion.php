
<?php

$conexion=pg_connect("host=localhost port=5432 dbname=HOSPITAL user=postgres password=villa13");
$query="SELECT  dni, apellido, nombre, sexo, fecha_nac FROM paientes";
if ($conexion){
     echo '';
}
else {
   echo 'ha ocurrido un error';
}

    ?>

<!-- id_paciente, id_obra_social, id_direccion, id_persona, id_contacto, dni, apellido, nombre, sexo, fecha_nac, contacto_flia  -->