<?php
require("conexion.php");

$descripcion = $_POST["descripcion"];
$monodroga = $_POST["monodroga"];
$precio = $_POST["precio"];
$query=("INSERT INTO vademecum ( descripcion, monodroga, precio  ) VALUES ('$descripcion', '$monodroga','$precio' )");
$consulta=pg_query($query);





pg_close();

echo 'se añadio un resgristro nuevo';         

?>
