<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/home.css">
    <!-- https://icons.getbootstrap.com/ -->
  </head>
<body>
<br>
<div class="container">
  <br>
  <div class="row justify-content-md-center">
    <div class="col-md-12">
      <form class="d-flex" role="buscar">
        <input class="form-control me-2" type="buscar" placeholder="buscar" aria-label="buscar">
        <button class="btn btn-outline-success" type="submit">buscar</button>
      </form>
        <hr class="mb-3">
    </div>


    <div class="col-md-4 mb-3">
      <h3 class="text-center">Datos  </h3>
      <form method="POST" action="alta.php" enctype="multipart/form-data">
        <input type="text" name="metodo" value="1" hidden>
      <div class="mb-3">
          <label class="form-label"> descripcion</label>
          <input type="text" class="form-control" name="apellido" required>
        </div>
        <div class="mb-3">
          <label class="form-label">monodroga </label>
          <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">precio </label>
          <input type="num" name="fecha_nac" class="form-control" required>
        </div>

       

        <div class="d-grid gap-2 col-12 mx-auto">
          <button type="submit" class="btn  btn btn-primary mt-3 mb-2">
            Registrar nuevo 
            <i class="bi bi-arrow-right-circle"></i>
          </button>
        </div>
        
      </form>
    </div>
    

<!-- select direccion.id_direccion from pacientes
Inner join direccion on  direccion.id_direccion = pacientes.id_direccion -->
    
    <?php
    include('conexion.php');
    $sql  = ("SELECT * FROM vademecum ");
    $query = pg_query($sql);
    $total = pg_num_rows($query);

    ?>
    <div class="col-md-8">
    <h3 class="text-center">Lista  <?php echo '(' . $total . ')'; ?></h3>
      <div class="row">
        <div class="col-md-12 p-2">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th scope="col">descripcion</th>
                  <th scope="col">monodroga</th>
                  <th scope="col">precio</th>

               

                </tr>
              </thead>
              <tbody>
              <?php
              while ($data = pg_fetch_array($query)) { ?>
                <tr>
                  
                  <td><?php echo $data['descripcion']; ?></td>
                  <td><?php echo $data['monodroga']; ?></td>
                  <td><?php echo $data['precio']; ?></td>
                  
                  <td>
                  <a href="detalles.php?id_persona=<?php echo $data['id_persona']; ?>" class="btn btn-warning mb-2"   title="Ver datos  <?php echo $data['apellido']; ?>">
                  <i class="bi bi-tv"></i> Ver</a>
                    <a href="formEditar.php?id_persona=<?php echo $data['id_persona']; ?>" class="btn btn-info mb-2"   title="Actualizar <?php echo $data['apellido']; ?>">
                    <i class="bi bi-arrow-clockwise"></i> Actualizar</a>
                    <a href="action.php?id_personas=<?php echo $data['id_persona']; ?>" class="btn btn-danger mb-2" title="Borrar <?php echo $data['apellido']; ?>">
                    <i class="bi bi-trash"></i> Borrar</a>
                  </td>







                  
                 
                  </td>
                </tr>
              <?php } ?>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php
  include('mensajes.php'); 
?>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script>
$(function(){
  $('.toast').toast('show');
});
</script>

</body>
</html>
<style>
    body{
    background-color: #f9f9f9 !important;
  }
  /* #f9f9f9 */
  .container{
    background-color: #fff;
    border-radius: 10px !important;
    margin-left:  30px;
    max-width: 250%;
  }
  h1{
    font-weight: 800;
    color: blueviolet;
  }
  p{
    font-size: 305px;
    font-weight: 800;
    color: orange;
  }
  p span{
    color: crimson;
  }
  label{
    color: black !important;
    font-weight: 500;

  }
  .bi-trash:hover{
    color: red !important;
  }
  .bi-arrow-clockwise:hover{
    color: red;
    font-weight: bold;
  }
  a{
    text-decoration: none;
  }
  .bi-arrow-left-circle{
    color: red;
  }
  .bi-arrow-left-circle:hover{
    color: red;
  }
  .fotoPerfil{
    margin: 0 auto;
    max-width: 250px;
}
.titleAlumno{
    color: red;
    font-weight: 800;
}
.logo{
  max-width: 50px;
}
.msjexito{
  color: green;
}
</style>