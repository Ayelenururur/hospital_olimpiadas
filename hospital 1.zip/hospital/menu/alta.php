<?php
require("conexion.php");

$apellido = $_POST["apellido"];
$nombre = $_POST["nombre"];
$fecha_nac = $_POST["fecha_nac"];
$query=("INSERT INTO personas ( apellido, nombre, fecha_nac  ) VALUES (   '$apellido', '$nombre','$fecha_nac' )");
$consulta=pg_query($conexion,$query);





pg_close();

echo 'se añadio un resgristro nuevo';         

?>
